===== PetsZone Shop =====

PetsZone Shop plugin adds shop features for PetsZone theme.


== Changelog ==

= 1.0.0 =

    * First release!