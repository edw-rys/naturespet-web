<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Tags -->
<div class="entry-tags"><?php the_tags('<i class="wdticon-bookmark"> </i> ', ' ', ''); ?></div><!-- Entry Tags -->