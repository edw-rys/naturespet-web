<a id="back-to-top" href="#">
    <span id="back-to-top-hover"></span>
    <span class="back-to-top-icon"><?php echo petszone_html_output($icon); ?></span>
    <span class="back-to-top-icon-1"><?php echo petszone_html_output($icon); ?></span>
    <span class="back-to-top-icon-2"><?php echo petszone_html_output($icon); ?></span>
</a>