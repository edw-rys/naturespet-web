<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'PetsZonePlusSiteToTop' ) ) {
    class PetsZonePlusSiteToTop {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            $this->load_modules();
            $this->frontend();
        }

        function load_modules() {
            include_once PETSZONE_PLUS_DIR_PATH.'modules/site-to-top/customizer/index.php';
        }

        function frontend() {
            $show = petszone_customizer_settings('show_site_to_top');
            if( $show ) {
                add_filter( 'body_class', array( $this, 'add_body_classes' ) );
                add_action( 'petszone_after_main_css', array( $this, 'enqueue_assets' ) );
                add_action( 'wp_footer', array( $this, 'load_template' ), 999 );
            }
        }

        function add_body_classes( $classes ) {
            $classes[] = 'has-go-to-top';
            return $classes;
        }

        function enqueue_assets() {
            wp_enqueue_style( 'site-to-top', PETSZONE_PLUS_DIR_URL . 'modules/site-to-top/assets/css/totop.css', false, PETSZONE_PLUS_VERSION, 'all' );
            wp_enqueue_script( 'go-to-top', PETSZONE_PLUS_DIR_URL . 'modules/site-to-top/assets/js/go-to-top.js', array('jquery'), PETSZONE_PLUS_VERSION, true );
        }

        function load_template() {
            $args = array(
                'icon' => '<i><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve"><style type="text/css">	.wdt-heading-icon01{fill:#FFC10E;}	.wdt-heading-icon02{fill:#231F20;}</style><g>	<g>		<path class="wdt-heading-icon01" d="M38.3,32.8L38.3,32.8c-0.8-0.6-1.5-1.4-2-2.4c-0.5-0.9-0.9-1.8-1-2.8l0,0c-0.7-3.9-4.1-6.8-8.1-6.8   s-7.4,2.9-8.1,6.8l0,0c-0.2,0.9-0.5,1.9-1,2.8c-0.5,0.9-1.2,1.7-2,2.4h0c-1.8,1.5-3,3.8-3,6.3c0,4.6,3.7,8.3,8.3,8.3   c1.1,0,2.1-0.2,3-0.6l0,0c0.9-0.3,1.9-0.5,2.9-0.5c1.1,0,2.1,0.2,3.1,0.5l0,0c0.9,0.3,1.8,0.5,2.8,0.5c4.6,0,8.3-3.7,8.3-8.3   C41.3,36.6,40.1,34.3,38.3,32.8L38.3,32.8z"></path>		<path class="wdt-heading-icon01" d="M14.8,21.9c0,2.6-2.1,4.7-4.7,4.7c-2.6,0-4.7-2.1-4.7-4.7c0-2.6,2.1-4.7,4.7-4.7   C12.7,17.2,14.8,19.3,14.8,21.9z"></path>		<path class="wdt-heading-icon01" d="M24.5,11.8c0,2.6-2.1,4.7-4.7,4.7c-2.6,0-4.7-2.1-4.7-4.7c0-2.6,2.1-4.7,4.7-4.7C22.4,7.1,24.5,9.2,24.5,11.8   z"></path>		<path class="wdt-heading-icon01" d="M39.5,21.9c0,2.6,2.1,4.7,4.7,4.7c2.6,0,4.7-2.1,4.7-4.7c0-2.6-2.1-4.7-4.7-4.7   C41.6,17.2,39.5,19.3,39.5,21.9z"></path>		<path class="wdt-heading-icon01" d="M29.8,11.8c0,2.6,2.1,4.7,4.7,4.7c2.6,0,4.7-2.1,4.7-4.7c0-2.6-2.1-4.7-4.7-4.7C31.9,7.1,29.8,9.2,29.8,11.8z   "></path>	</g>	<g>		<path class="wdt-heading-icon02" d="M29.8,45.3c-1.1,0-2.2-0.2-3.3-0.6c0,0-0.1,0-0.1,0c-0.7-0.3-1.6-0.4-2.5-0.4c-1,0-1.8,0.2-2.6,0.5   c-0.1,0-0.1,0-0.2,0.1c-1,0.3-2,0.5-3.1,0.5c-5.2,0-9.4-4.2-9.4-9.4c0-2.8,1.2-5.4,3.3-7.2c0,0,0.1-0.1,0.1-0.1   c0.7-0.5,1.2-1.2,1.7-2c0.4-0.8,0.7-1.6,0.9-2.4c0-0.1,0-0.1,0-0.2c0.9-4.4,4.7-7.6,9.2-7.6c4.5,0,8.4,3.2,9.2,7.6   c0,0,0,0.1,0,0.2c0.1,0.8,0.4,1.6,0.9,2.4c0.5,0.8,1.1,1.5,1.7,2c0,0,0.1,0.1,0.1,0.1c2.1,1.8,3.3,4.4,3.3,7.2   c0,0.6-0.5,1.2-1.2,1.2c-0.6,0-1.2-0.5-1.2-1.2c0-2.1-0.9-4.1-2.6-5.5c0,0,0,0-0.1-0.1c-0.9-0.7-1.6-1.6-2.2-2.6   c-0.6-1-0.9-2-1.1-3c0,0,0-0.1,0-0.1c-0.6-3.4-3.5-5.8-7-5.8s-6.4,2.5-7,5.8c0,0,0,0.1,0,0.1c-0.2,1-0.6,2-1.1,3   c-0.6,1-1.3,1.9-2.2,2.6c0,0,0,0-0.1,0.1c-1.6,1.4-2.6,3.3-2.6,5.5c0,3.9,3.2,7.1,7.1,7.1c0.8,0,1.6-0.2,2.4-0.4c0,0,0.1,0,0.1,0   c1-0.4,2.1-0.6,3.3-0.6c1.1,0,2.2,0.2,3.1,0.5c0.1,0,0.1,0,0.2,0.1c0.8,0.3,1.7,0.5,2.6,0.5c2.5,0,4.7-1.2,6-3.3   c0.3-0.5,1.1-0.7,1.6-0.4c0.5,0.3,0.7,1.1,0.4,1.6C36,43.6,33,45.3,29.8,45.3z"></path>		<path class="wdt-heading-icon02" d="M6.8,24.5c-3.2,0-5.9-2.6-5.9-5.9c0-3.2,2.6-5.9,5.9-5.9c3.2,0,5.9,2.6,5.9,5.9c0,1.6-0.6,3-1.7,4.2   c-0.5,0.5-1.2,0.5-1.6,0c-0.5-0.5-0.5-1.2,0-1.6c0.7-0.7,1-1.6,1-2.5c0-2-1.6-3.6-3.6-3.6s-3.6,1.6-3.6,3.6s1.6,3.6,3.6,3.6   c0.6,0,1.2,0.5,1.2,1.2S7.5,24.5,6.8,24.5L6.8,24.5z"></path>		<path class="wdt-heading-icon02" d="M16.5,14.4c-3.2,0-5.9-2.6-5.9-5.9s2.6-5.9,5.9-5.9s5.9,2.6,5.9,5.9c0,1.6-0.6,3-1.7,4.2   c-0.5,0.5-1.2,0.5-1.6,0c-0.5-0.5-0.5-1.2,0-1.6c0.7-0.7,1-1.6,1-2.5c0-2-1.6-3.6-3.6-3.6S13,6.5,13,8.5c0,2,1.6,3.6,3.6,3.6   c0.6,0,1.2,0.5,1.2,1.2C17.7,13.8,17.2,14.4,16.5,14.4L16.5,14.4z"></path>		<path class="wdt-heading-icon02" d="M31.2,14.4c-3.2,0-5.9-2.6-5.9-5.9s2.6-5.9,5.9-5.9c3.2,0,5.9,2.6,5.9,5.9c0,1.6-0.6,3-1.7,4.2   c-0.5,0.5-1.2,0.5-1.6,0c-0.5-0.5-0.5-1.2,0-1.6c0.7-0.7,1-1.6,1-2.5c0-2-1.6-3.6-3.6-3.6s-3.6,1.6-3.6,3.6c0,2,1.6,3.6,3.6,3.6   c0.6,0,1.2,0.5,1.2,1.2C32.4,13.8,31.9,14.4,31.2,14.4L31.2,14.4z"></path>		<path class="wdt-heading-icon02" d="M40.9,24.5c-3.2,0-5.9-2.6-5.9-5.9c0-3.2,2.6-5.9,5.9-5.9c3.2,0,5.9,2.6,5.9,5.9c0,1.6-0.6,3-1.7,4.2   c-0.5,0.5-1.2,0.5-1.6,0c-0.5-0.5-0.5-1.2,0-1.6c0.7-0.7,1-1.6,1-2.5c0-2-1.6-3.6-3.6-3.6c-2,0-3.6,1.6-3.6,3.6   c0,2,1.6,3.6,3.6,3.6c0.6,0,1.2,0.5,1.2,1.2C42.1,24,41.6,24.5,40.9,24.5z"></path>	</g></g></svg></i>'
            );

            echo petszone_get_template_part( 'site-to-top/layouts/', 'template', '', $args );
        }
    }
}

PetsZonePlusSiteToTop::instance();