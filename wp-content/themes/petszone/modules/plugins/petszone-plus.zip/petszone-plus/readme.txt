======= PetsZone Plus =====

PetsZone Plus plugin adds additonal features for PetsZone theme.


== Changelog ==


= 1.0.1 =

    * Deprecated Errors Fixed

= 1.0.0 =

    * First release!